import React from 'react'
import WhatshotIcon from '@mui/icons-material/Whatshot';
function Footer() {
  return (
    <div className="footer"> 
        <WhatshotIcon/>
    </div>
  )
}

export default Footer