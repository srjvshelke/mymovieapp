import React from 'react'

function Body() {
  return (
    <div className='body'>
        <h2> Body </h2>
    </div>
  );
};

export default Body